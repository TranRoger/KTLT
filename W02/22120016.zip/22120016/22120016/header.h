#pragma once

#include <iostream>

using namespace std;

bool isPerfect(int);