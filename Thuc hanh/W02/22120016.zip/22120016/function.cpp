﻿#include "header.h"

void giaTri(int* pointer) {
	cout << "Gia tri moi cho con tro: ";
	cin >> *pointer;
}