#pragma once

#include <iostream>
#include <fstream>

using namespace std;

void giaTri(int*);