#pragma once

#include <iostream>

using namespace std;

void createArray(int*&, int&);
void output(int*, const int&);
void checkSorted(int*, const int&);
int sum(int*, const int&);
int max(int*, const int&);
bool isPrime(const int&);
void findPrime(int*, const int&);
void reverse(int*, const int&);