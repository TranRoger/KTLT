#pragma once

#include <iostream>

using namespace std;

void printArray(int *, const int &, const int &);
int power(const int &, const int &);
int sum(int *, const int &, const int &);