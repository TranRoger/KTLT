#pragma once

#include <iostream>
#include <fstream>

using namespace std;

char* reverse(char*);
int** createMatrix(const char*, int&, int&);
char* replace(char*, char*, char*);
int find(char*, char*, const int&);