#pragma once

enum Color {
    Black = 0,
    LightBlue = 3,
    White = 15
};