#pragma once

#include "../Helper/string.h"
#include "../Object/Player.h"
#include "../KeyboardHandler/HandleInput.h"
#include "DisplayMatrix.h"
#include "../Object/PlayerList.h"

class Game {
private:
public:
    static bool display(Player&, bool);
};

bool Game::display(Player& p, bool rule) {
    bool result = true;
    do {
        system("cls");
        p.setScore(p.getProgress().getCurrent().score());
        cout << "Score: " << p.score() << endl << endl;
        Matrix matrix(p.getProgress().getCurrent());

        if (matrix.stuck()) {
            result = true;
            system("cls");
            cout << "You lost!" << endl;
            if (rule) {
                cout << "Try again?" << endl;
                int t = KeyboardInputHandler::next();
                if (27 == t) {
                    break;
                }
                if (Enter == t) {
                    p.getProgress().undo();
                    continue;
                }
            }
            else {
                break;
            }
        }
        else if (matrix.max() == 2048) {
            result = 1;
            system("cls");
            cout << "Congratulation!\nDo you want to continue?" << endl;
            int c = KeyboardInputHandler::next();
            if (27 == c) {
                break;
            }
        }

        DisplayMatrix::display(matrix);
        int k = KeyboardInputHandler::next();

        if (k == Up) {
            matrix.moveUp();
            matrix.addRandom();
            p.getProgress().update(matrix);
        }
        if (k == Down) {
            matrix.moveDown();
            matrix.addRandom();
            p.getProgress().update(matrix);
        }
        if (k == Left) {
            matrix.moveLeft();
            matrix.addRandom();
            p.getProgress().update(matrix);
        }
        if (k == Right) {
            matrix.moveRight();
            matrix.addRandom();
            p.getProgress().update(matrix);
        }
        if (k == Undo && rule) {
            try {
                p.getProgress().undo();
            } catch (...) {
                cout << "Cannot undo" << endl;
            }
        }
        if (k == Redo && rule) {
            try {
                p.getProgress().redo();
            } catch (...) {
                cout << "Cannot redo" << endl;
            }
        }
        if (k == 27) {
            system("cls");
            cout << "Do you want to exit?" << endl;
            k = KeyboardInputHandler::next();
            if (k == Enter) {
                return false;
            }
        }
    } while (true);

    return result;
}