#pragma once 

#include <iostream>
#include <conio.h>
#include "../KeyboardHandler/Keymap.h"

using std::cout, std::endl;

class KeyboardInputHandler {
public:
    static int next();
};