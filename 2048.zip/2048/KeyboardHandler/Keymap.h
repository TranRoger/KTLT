#pragma once

enum Keys : int {
    Arrow = 224,
    Up = 72,
    Down = 80,
    Left = 75,
    Right = 77,
    Enter = 13,
    Redo = 82,
    Undo = 85
};